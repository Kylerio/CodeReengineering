import java.awt.Color;

import javax.swing.JButton;

public class BlueButton extends JButton {
	public BlueButton(String text) {
		super(text);
		this.setBackground(Color.BLUE);
	}
}
