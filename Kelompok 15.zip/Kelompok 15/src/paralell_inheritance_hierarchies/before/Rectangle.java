package paralell_inheritance_hierarchies.before;

public class Rectangle extends Shape2D {

	@Override
	public float area() {
		// TODO Auto-generated method stub
		return width * height;
	}

}